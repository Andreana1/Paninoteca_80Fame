<?php
$server = 'localhost';
$username = 'root';
$password = '';
$database = 'dbpan';
try{
	$conn = new PDO("mysql:host=$server;dbname=$database;", $username, $password);
} catch(PDOException $e){
	die( "Connection failed: " . $e->getMessage());
}


 echo "Prova db"; 
?>