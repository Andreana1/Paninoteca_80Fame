<?php


include("auth.php"); //include auth.php file on all secure pages ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Benvenuto</title>
<link href="login.css" type="text/css" rel="stylesheet" />
</head>
<body>
<div class="form">
<p>Benvenuto <?php echo $_SESSION['username']; ?>!</p>
<p><a href="index.php">Ordina!</a></p>
<a href="logout.php">Logout</a>

<br /><br /><br /><br />
</div>
</body>
</html>
