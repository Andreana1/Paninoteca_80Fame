﻿   <?php   
 session_start();  
 $connect = mysqli_connect("localhost", "root", "", "register");  
 if(isset($_POST["add_to_cart"]))  
 {  
      if(isset($_SESSION["shopping_cart"]))  
      {  
           $item_array_id = array_column($_SESSION["shopping_cart"], "item_id");  
           if(!in_array($_GET["id"], $item_array_id))  
           {  
                $count = count($_SESSION["shopping_cart"]);  
                $item_array = array(  
                     'item_id'               =>     $_GET["id"],  
                     'item_name'               =>     $_POST["hidden_name"],  
                     'item_price'          =>     $_POST["hidden_price"],  
                     'item_quantity'          =>     $_POST["quantity"]  
                );  
                $_SESSION["shopping_cart"][$count] = $item_array;  
           }  
           else  
           {  
                echo '<script>alert("Prodotto già aggiunto")</script>';  
                echo '<script>window.location="index.php"</script>';  
           }  
      }  
      else  
      {  
           $item_array = array(  
                'item_id'               =>     $_GET["id"],  
                'item_name'               =>     $_POST["hidden_name"],  
                'item_price'          =>     $_POST["hidden_price"],  
                'item_quantity'          =>     $_POST["quantity"]  
           );  
           $_SESSION["shopping_cart"][0] = $item_array;  
      }  
 }  
 if(isset($_GET["action"]))  
 {  
      if($_GET["action"] == "delete")  
      {  
           foreach($_SESSION["shopping_cart"] as $keys => $values)  
           {  
                if($values["item_id"] == $_GET["id"])  
                {  
                     unset($_SESSION["shopping_cart"][$keys]);  
                     echo '<script>alert("Rimosso")</script>';  
                     echo '<script>window.location="index.php"</script>';  
                }  
           }  
      }  
 }  
 ?>  
 <!DOCTYPE html>  
 <html>  
      <head>  
           <title>Paninoteca 80Fame - Il tuo Ordine</title>  
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
            <link href="carrel.css" type="text/css" rel="stylesheet" />


      </head>  


      
 <header class="top">
      <a href="index.html"><img id= "logo"
			      src="images/LOGO.png?token=${sessionScope.token}" width=172px, height=140px></a>
      
         <nav>
			<ul id="menu">
					    <li><a href="index.html">&ensp;&ensp;&ensp;Home</a></li> 
						<li><a href="login.php">Prenotami Qui</a></li>
						<li><a href="contatti.html">Contatti</a></li>
						<li>Benvenuto/a <?php echo $_SESSION['username']; ?>! - <a href="logout.php">Logout</a></li>
						
</ul>
</nav>

	

    </header>
      
     
   
	<section class="centro">
	
	<h2>Da 80 fame</h2>
           <br />  
           <div class="container" style="width:700px;">  
                <h3 align="center">Paninoteca 80Fame - Prenotazione</h3><br />  
                <?php  
                $query = "SELECT * FROM tbl_product ORDER BY id ASC";  
                $result = mysqli_query($connect, $query);  
                if(mysqli_num_rows($result) > 0)  
                {  
                     while($row = mysqli_fetch_array($result))  
                     {  
                ?>  
                               <div class="col-md-4">  
                     <form method="post" action="index.php?action=add&id=<?php echo $row["id"]; ?>">  
                          <div style="border:1px solid #333; background-color:#f1f1f1; border-radius:5px; padding:16px;" align="center">  
                               <img src="<?php echo $row["image"]; ?>" class="img-responsive" /><br />  
                               <h4 class="text-info"><?php echo $row["name"]; ?></h4>  
                               <h4 class="text-danger">€ <?php echo $row["price"]; ?></h4>  
                               <input type="text" name="quantity" class="form-control" value="1" />  
                               <input type="hidden" name="hidden_name" value="<?php echo $row["name"]; ?>" />  
                               <input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>" />  
                               <input type="submit" name="add_to_cart" style="margin-top:5px;" class="btn btn-success" value="Aggiungi al carrello" />  
                          </div>  
                     </form>  
                </div>  
                <?php  
                     }  
                }  
                ?>  
                <div style="clear:both"></div>  
                <br />  
                <h3>Dettaglio Ordine</h3>  
                <div class="table-responsive">  
                     <table class="table table-bordered">  
                          <tr>  
                               <th width="40%">Prodotto</th>  
                               <th width="10%">Quantità</th>  
                               <th width="20%">Prezzo</th>  
                               <th width="15%">Totale</th>  
                               <th width="5%">Azione</th>  
                          </tr>  
                          <?php   
                          if(!empty($_SESSION["shopping_cart"]))  
                          {  
                               $total = 0;  
                               foreach($_SESSION["shopping_cart"] as $keys => $values)  
                               {  
                          ?>  
                          <tr>  
                               <td><?php echo $values["item_name"]; ?></td>  
                               <td><?php echo $values["item_quantity"]; ?></td>  
                               <td>€ <?php echo $values["item_price"]; ?></td>  
                               <td>€ <?php echo number_format($values["item_quantity"] * $values["item_price"], 2); ?></td>  
                               <td><a href="index.php?action=delete&id=<?php echo $values["item_id"]; ?>"><span class="text-danger">Rimuovi</span></a></td>  
                          </tr>  
                          <?php  
                                    $total = $total + ($values["item_quantity"] * $values["item_price"]);  
                               }  
                          ?>  
                          <tr>  
                               <td colspan="3" align="right">Total</td>  
                               <td align="right">€ <?php echo number_format($total, 2); ?></td>  
                               <td></td>  
                          </tr>  
                          <?php  
                          }  
                          ?>  

                     </table>  
<br>
<br>
<br>
<div class="form">

<form action="" method="post" name="prenotazione">
<p>Selezione l'ora</p><select name="mydropdown">
<option value="Ora">19:00</option>
<option value="Ora">20:00</option>
<option value="Ora">21:00</option>
<option value="Ora">21:00</option>
</select><br><br>
<input type="text" name="Indirizzo" placeholder="Indirizzo via /corso"  required  value="" pattern="[A-Za-z0-9\s]{1,10}" title="Indirizzo  massimo 30 caratteri" /> <input type="text" name="numero" placeholder="numero"  required  value="" pattern="[A-Za-z0-9]{1,4}" title="Numero civico massimo 4 caratteri" /><br><br>
<input type="text" name="Telefono" placeholder="Telefono" required value="" pattern="[0-9]{1,10}" title="Numero di telefono non valido, massimo 10 caratteri" /><br><br>
 <input type="submit" name="Prenota"  formaction="prenotazione.php" style="margin-top:5px;" class="btn btn-success" value="Prenota" />
</form>
</div>

                </div>  
           </div>  
 
           <br />  
      </body>  
 </html>
   