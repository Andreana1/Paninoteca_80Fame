<?php
$DB_host     = 'localhost';
$DB_user     = 'root';
$DB_password = '';
$DB_name     = 'paninoteca';
?>