<?php
chdir($_SERVER['DOCUMENT_ROOT']);
header('Location: webpages/public/mostra_catalogo.php?id='.rand());
?>