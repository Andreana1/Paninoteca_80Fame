﻿<?php
include_once('../../components/admin/magazzino/IArticolo.php');

class Carrello {
   
   private $ArticoliInCarrello = array();
   private $totale = 0;
   private $numeroArticoli = 0;
   
    /**
      * Restituisce numero di articoli presenti nel carrello 
      * @return int  numeroArticoli
      * 
      */
    public function getNumeroArticoli(){
       return (int)$this->numeroArticoli; 
    }
   
     /**
      * Restituisce il totale del carrello
      * @return float totale
      * 
      */
    public function getTotale(){
       return (float)$this->totale;
      
    }
     /**
      * Restituisce il totale in formato euro
      * @return string totale
      * 
      */
    public function getTotaleFormattatoEuro(){
       return number_format($this->getTotale(), 2, ',', '.'); 
    }
    /**
      * svuota il carrello.
      * @return boolean true
      * 
      */
    public function svuota(){
        unset($_SESSION['carrello']);
        return true;
    }
    
     /**
      * aggiunge articolo al carrello
      * 
      */
    	public function aggiungiArticolo(IArticolo $IArticolo, $quantita=1){
        
        $IArticoloPresente = false;  
        $IArticoloEliminato = false;
        $quantita= (int)$quantita;
        
        // Loop tra gli ArticoliInCarrello per verificare la presenza dell'IArticolo.
        foreach($this->ArticoliInCarrello as $key => &$IArticoloInCarrello) {
            
            // Se l'IArticolo è gia presente nel carrello aggiorna quantità+subtotale
            if ($IArticoloInCarrello['articolo'] == $IArticolo) {
                $IArticoloPresente = true;
                $IArticoloInCarrello['quantita'] += $quantita;
                $IArticoloInCarrello['subtotale'] += $IArticolo->getPrezzo()*$quantita;
                
                // Ma se l'IArticolo raggiunge qtà negativa viene rimosso dal carrello
                if ($IArticoloInCarrello['quantita'] <= 0) {
                    unset($this->ArticoliInCarrello[$key]);
                    $IArticoloEliminato = true;            
                } 
                
                // Rimozione e aggiornamento implicano agg. dei totali carrello.
                $this->totale += $IArticolo->getPrezzo()*$quantita;
                $this->numeroArticoli += $quantita;                  
                
                break;
            }
        } 
        
        // Se IArticolo non è presente e ha quantità >0 si aggiunge al carrello
        if(!$IArticoloPresente && $quantita > 0){
             $this->ArticoliInCarrello[] = array("articolo"=>$IArticolo,
                                    "quantita"=>$quantita,
                                    "subtotale"=>$IArticolo->getPrezzo()*$quantita
                                    );                             
             // e si ricalcolano i suoi totali
             $this->totale += $IArticolo->getPrezzo()*$quantita;
             $this->numeroArticoli += $quantita; 
        }
      
    }
	 /**
      * elimina articolo dal carrello
      */
    function eliminaArticolo($codice)
    {
	
	foreach($this->ArticoliInCarrello as $key => &$IArticoloInCarrello) {
                        if ($IArticoloInCarrello['articolo']->getCodice() == $codice) {
						if($IArticoloInCarrello['quantita']-1<=0)
							unset($this->ArticoliInCarrello[$key]);
						else
						{
							
                   					$IArticoloInCarrello['quantita'] --;
							$IArticoloInCarrello['subtotale'] = $IArticoloInCarrello['articolo']->getPrezzo()*$IArticoloInCarrello['quantita'];
							
						}
						$this->totale -= $IArticoloInCarrello['articolo']->getPrezzo();
						$this->numeroArticoli -= 1;
						break;
			}
    	}
    }
     /**
      * Restituisce l'array di articoli nel carrello
      * @return array ArticoliInCarrello
      * 
      */
    function getArticoliCarrello()
    {
    return $this->ArticoliInCarrello;
    }
}  

?>
