<?php

include_once('../../components/admin/magazzino/Articolo.php');
include_once('../../components/admin/magazzino/IArticoloDettaglio.php');
include("conn.ini");
class Catalogo {

    private $articoli=array();
    /**
    *vuoto
    */
	public function __construct()
	{
		
	}
	 /**
      * Restituisce articoli
      * @return array articoli
      * 
      */
    	public function getArticoli() {

        	return $this->articoli;

    	}

	 /**
      * aggiunge articolo al catalogo
      * 
      */
	public function aggiungiArticolo(IArticoloDettaglio $IArticolo)
	{
		$this->articoli[count($this->articoli)]=array('articolo'=>$IArticolo);
	}
 /**
      * Restituisce l'articolo cercato tramite codice 
      *altrimenti null
      * @return string valore
      * 
      */
	public function cercaArticolo($codice)
	{
		foreach($this->articoli as $valore)
		{
			if($valore['articolo']->getCodice()==$codice)
				return $valore;
		}
		return null;
	}
}

?>
