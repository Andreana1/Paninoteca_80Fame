<?php

class Paginazione
{
	private $pag_corrente;
	private $num_pag;
	/**
	*si setta num_pag e pag_corrente a 1
	*/	
	public function __construct($num_pag=0)
	{
		$this->num_pag=$num_pag;
		$this->pag_corrente=1;
	}
	
	/**
	*aggiorna la pagina precedente
	*restituisce la pagina precedente
	*@return int pag_prec
	*/
	public function prec()
	{
		$pag_prec=$this->pag_corrente;
		if($this->controlloPrec())
			$pag_prec-=1;
		return $pag_prec;
	}
	
	/**
	*aggiorna la pagina successiva
	*restituisce la pagina successiva
	*@return int pag_succ
	*/
	public function next()
	{
		$pag_succ=$this->pag_corrente;
		if($this->controlloSucc())
			$pag_succ+=1;
		return $pag_succ;
	}
	
	/**
	*restituisce numero di pagine
	*@return int num_pag
	*/
	public function getNumPag()
	{
		return (int)$this->num_pag;
	}

	/**
	*controlla se esiste una pagina precedente
	*@return boolean 
	*/
	public function controlloPrec()
	{
		if($this->pag_corrente<=1)
			return false;
		return true;
	}
	/**
	*controlla se esiste una pagina successiva
	*@return boolean 
	*/
	
	public function controlloSucc()
	{
		if($this->pag_corrente>=$this->num_pag)
			return false;
		return true;
	}
	/**
	*setta pagina corrente
	*/
	
	public function setCurrent($pag)
	{
		if($pag>=1&&$pag<=$this->num_pag)
			$this->pag_corrente=$pag;
		else
			$this->pag_corrente=$num_pag;
	}
	/**
	*restituisce pagina corrente

	*@return int pag_corrente
	*/
	public function getCurrent()
	{
		return (int)$this->pag_corrente;
	}
}
?>
