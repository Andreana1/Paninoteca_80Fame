<?php
include_once('Carrello.php');
include_once('Catalogo.php');
include_once('Paginazione.php');
include("conn.ini");

class ECommerceFacade {
	public static $num_el;
	public static $num_el_pag=1;
	public static $catalogo;
	 /**
	 *inizializza il carrello
      * Restituisce il carrello
      * @return Carrello carrello   
      * 
      */
    private static function inizializzaCarrello() {
        $carrello = new Carrello();
        if (!isset($_SESSION['carrello'])) {
            $_SESSION['carrello'] = new Carrello();
        } 
        $carrello = $_SESSION['carrello'];
        return $carrello;   
    }
     /**
      *setta il numero di elementi per pagina 
            */
	public static function setNumEl($num)
	{
		if($num!=ECommerceFacade::$num_el_pag)
		{
			ECommerceFacade::$num_el_pag=(int)$num;
		}
	}
	 /**
      * Inizializza la paginazione
      richiama il metodo aggiorna 
      * @return Paginazione paginazione
      * 
      */
	private static function inizializzaPaginazione() {
        if (!isset($_SESSION['paginazione'])){
		ECommerceFacade::aggiorna();
        }
        $paginazione = $_SESSION['paginazione'];
        return $paginazione;   
    }
     /**
     aggiorna gli articoli  per ogni pagina 
      * Restituisce la variabile di sessione $_SESSION['paginazione'];
      * @return Paginazione $_SESSION['paginazione'];
      * 
      */
	public static function aggiorna(){
		$result=mysql_query("SELECT COUNT(*) FROM catalogo");
		$num=mysql_fetch_array($result);
		$num_el=$num[0];
		$numero=((int)(((int)$num_el)/((int)ECommerceFacade::$num_el_pag)));
		if(($num_el%ECommerceFacade::$num_el_pag)!=0)
			$numero++;
            $_SESSION['paginazione'] = new Paginazione($numero);
		return $_SESSION['paginazione'];
	}

	/**
	*restituisce il carrello
	*@return Carrello carrello
	*/
    public static function getCarrello() {
        return ECommerceFacade::inizializzaCarrello();
    }
    
	/**
	*inizializza il catalogo e ritorna un catalogo paginato
	*@return Catalogo catalogo
	*/
    private static function inizzializzaCatalogo() {	
	$paginazione=ECommerceFacade::getPaginazione();
	$pag_corrente=$paginazione->getCurrent()*ECommerceFacade::$num_el_pag;
	return ECommerceFacade::getCatalogoPaginato(($paginazione->getCurrent()-1)*ECommerceFacade::$num_el_pag,$pag_corrente);
    }
    
	/**
	*restituisce il Catalogo
	*@return Catalogo catalogo
	*/
	public static function getCatalogo()
	{
		return ECommerceFacade::inizzializzaCatalogo();
	}
	
	/**
	*restituisce un obj paginazione
	*@return Paginazione paginazione
	*/
	public static function getPaginazione()
	{
		return ECommerceFacade::inizializzaPaginazione();
	}
	
	/**
	*restituisce il catalogo paginato
	*@return Catalogo catalogo
	*/	
	public static function getCatalogoPaginato($num_iniziale,$num_finale)
	{
		$catalogo=new Catalogo();
		$tabRis=mysql_query("SELECT * FROM catalogo order by ID LIMIT $num_finale");
			$inf=((int)(mysql_num_rows($tabRis))-$num_iniziale);
			$result=mysql_query("SELECT * from (SELECT * from (SELECT * FROM catalogo order by ID LIMIT $num_finale) AS A order by A.ID DESC LIMIT $inf)AS B order by B.ID ASC");
			$i=0;
			while($row=mysql_fetch_array($result))
			{
				$art=new Articolo($row[1],$row[2],$row[3],$row[4]);
				$catalogo->aggiungiArticolo($art);
				$i++;
			}
			return $catalogo;
			mysql_free_result($result);
	}
	
	/**
	*restituisce il catalogo filtrato per nome descrizione e marca ,anche parziale
	*@return Catalogo catalogo
	*/
	public static function getCatalogoFiltrato($nome="",$descrizione="",$marca="")
	{
		$catalogo=new Catalogo();
		$query= "SELECT * FROM catalogo WHERE";
		
			$array['codice'] = $nome;
			$array['Descrizione'] = $descrizione;
			$array['Marca'] = $marca;
			$flag =true;
			$query1 ="";
			foreach($array as $chiave=> $valore)
				{
				if($valore!="")
					if($flag)
					{
					$flag = false;
					$query = $query." $chiave LIKE '%$valore%'"; 
					}
					else
					$query = $query." AND $chiave LIKE '%$valore%' ";
						
				}
		
		
		$tabRis=mysql_query($query)or die("query non eseguita;");
		
			while($row=mysql_fetch_array($tabRis))
			{
				$art=new Articolo($row[1],$row[2],$row[3],$row[4]);
				$catalogo->aggiungiArticolo($art);
			}
			return $catalogo;
	}

}
?>
