<?php

   interface IArticolo {
 /**
      * Restituisce codice dell'articolo
      * @return string codice
      * 
      */
      public function getCodice();
       /**
      * Restituisce la marca dell'articolo
      * @return string marca
      * 
      */
      public function getMarca();
       /**
      * Restituisce il prezzo dell'articolo
      * @return float prezzo
      * 
      */
      public function getPrezzo();     
  }
?>
