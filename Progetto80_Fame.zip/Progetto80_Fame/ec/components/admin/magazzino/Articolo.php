<?php
include_once('IArticoloDettaglio.php');

/**
* class Articolo.
* Articolo d magazzino.
*/
  class  Articolo implements IArticoloDettaglio {
      

      private $codice;
      private $marca;
      private $prezzo;
      private $descrizione;
   

      public function __construct($codice=0,$descrizione="", $marca="", $prezzo=0 ){
         $this->codice = $codice;
         $this->marca = $marca;
         $this->prezzo = $prezzo; 
         $this->descrizione = $descrizione;
      } 
      
      /**
      * Restituisce il codice dell'articolo
      * @return string codice
      * 
      */
      public function getCodice() {
          return (string) $this->codice;
      }
      
      /**
      * Restituisce il nome dell'articolo
      * @return string nome
      * 
      */
      public function getMarca() {
        return (string)$this->marca;
      } 
       
      /**
      * Restituisce la descrizione dell'articolo
      * @return string descrizione
      * 
      */
       public function getDescrizione() {
        return (string)$this->descrizione;
      }   
       /**

      * Restituisce il prezzo dell'articolo

      * @return float prezzo

      * 

      */
      public function getPrezzo() {
          return (float)$this->prezzo;
      }
      
      /**
      * setta il codice dell'articolo
      * 
      * 
      */
      public function setCodice($codice) {
          $this->codice = $codice;
      }
       /**

      * setta la marca dell'articolo

      * 

      */
      public function setMarca($marca) {
        $this->marca=$marca;
      } 
       /**

      * setta la descrizione dell'articolo

      */
      public function setDescrizione($descrizione) {
        $this->descrizione=$descrizione;
      }       
	 /**

      *setta prezzo dell'articolo

      */      
      public function setPrezzo($prezzo) {
        $this->prezzo = (int)$prezzo;
      }
      
      
     

  }
?>
