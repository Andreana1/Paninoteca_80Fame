<?php

	interface IArticoloDettaglio extends IArticolo{


      		public function getDescrizione();

  	}



?>
