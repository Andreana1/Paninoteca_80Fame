<?php
   interface IArticoloDettaglio extends IArticolo{

 /**
      * Restituisce la descrizione dell'articolo
      * @return string descrizione
      * 
      */
      public function getDescrizione();
  
}

?>
