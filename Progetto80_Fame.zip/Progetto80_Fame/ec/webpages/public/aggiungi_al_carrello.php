<?php

include_once('../../components/public/ecommerce/ECommerceFacade.php');
session_start();
$carrello = ECommerceFacade::getCarrello();

if ( isset($_GET['codice']) && isset($_GET['marca']) && isset($_GET['prezzo']) ) {
    
    $codiceArticolo = $_GET['codice'];
    $marcaArticolo = $_GET['marca'];
    $prezzoArticolo = $_GET['prezzo'];
    
    $articoloSelezionato = new Articolo($codiceArticolo,"",$marcaArticolo,$prezzoArticolo);   
    $carrello->aggiungiArticolo($articoloSelezionato);       
}  

	if ( isset($_GET['svuota']))
    		$carrello->svuota();
	header("Location: mostra_catalogo.php");
	die(); 


?>             
