<?php

include_once('../../components/public/ecommerce/ECommerceFacade.php');
session_start();
$carrello = ECommerceFacade::getCarrello();

if(isset($_GET['cod']))
{
	$codice=$_GET['cod'];
	$carrello->eliminaArticolo($codice);
	if($carrello->getNumeroArticoli())
		header("Location:mostra_catalogo.php");
	header("Location:mostra_carrello.php");
}



?>             
