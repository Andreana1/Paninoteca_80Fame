<?php
include_once('../../components/public/ecommerce/ECommerceFacade.php');
include_once('../../components/admin/magazzino/IArticolo.php');

session_start();
$carrello = ECommerceFacade::getCarrello();
$listaArticoli = $carrello->getArticoliCarrello();
if(count($listaArticoli)==0)
	header('Location:mostra_catalogo.php');
?>
<html>
<head>
<title>Carrello</title>
</head>
<body>
<h1>Carrello</h1><br>
<table border='1'>
                        <tr>
                           <th>Codice</th>
                           <th>Marca</th>
                           <th>Prezzo</th>
                           <th>Quantit&agrave;</th>
                           <th>Totale</th>
                           <th>Operazione</th>
			</tr>
			<?php
			foreach( $listaArticoli as $value)
				echo"<tr><td>".$value['articolo']->getCodice()."<td>".$value['articolo']->getMarca()."<td>".$value['articolo']->getPrezzo()."<td>".$value['quantita']."<td>".$value['subtotale']."<td><a href=rimuovi_dal_carrello.php?cod=".$value['articolo']->getCodice()." onclick=\"return confirm('Elimina articolo?')\">Elimina</a></tr>";
			
			?>   
		                     
</table>
<a href="aggiungi_al_carrello.php?svuota=1" onclick="return confirm('Azzerare il carrello?')"> Svuota il carrello</a>
<a href="mostra_catalogo.php"> Torna al catalogo</a>
</body>
</html>
