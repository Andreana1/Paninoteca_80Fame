<?php
include_once('../../components/public/ecommerce/ECommerceFacade.php');
session_start();
if(isset($_COOKIE['num']))
{
	ECommerceFacade::$num_el_pag=$_COOKIE['num'];
	$paginazione=ECommerceFacade::aggiorna();
}	
else
{
	ECommerceFacade::$num_el_pag=1;
	$paginazione=ECommerceFacade::getpaginazione();
}
$carrello = ECommerceFacade::getCarrello();

if(isset($_GET['pag']))
{
	$pag=$_GET['pag'];
	if($pag == "cerca" )
		$catalogo = ECommerceFacade::getCatalogoFiltrato($_GET['nome'],$_GET['descr'],$_GET['mar']);
	else
	{
		$paginazione->setCurrent($pag);
		$catalogo = ECommerceFacade::getCatalogo();
	}
}
else
{
	$pag="";
	$catalogo = ECommerceFacade::getCatalogo();
}

$_SESSION['catalogo']=$catalogo;
?>
<html>

<head>
<title>eCommerce Demo</title>

<script>
function CatalogoFiltrato(obj)
{
array_input = obj.getElementsByTagName("input");
nome = array_input[0].value;
descr = array_input[1].value;
mar = array_input[2].value;
document.location.href="../../webpages/public/mostra_catalogo.php?pag=cerca&nome="+nome+"&descr="+descr+"&mar="+mar;
return false;
}
function confermaAcquisto(articolo){
	return confirm("Confermi l'acquisto di " + articolo + " ?");
}
function cambia_elementi(select)
{
	document.cookie="num="+select.value;
	document.location.href="../../webpages/public/mostra_catalogo.php";
}
</script>
<link rel="stylesheet" href="stile.css">
</head>

<body>
<h1>Catalogo online</h1>
<hr/>


<div style="display:inline;float:left;">
	<p>
		Utente: <strong>Visitatore</strong> | <a href="#">Login</a> <!--| <a href="#">Downoload catalogo .PDF</a>-->
	</p>
</div>

<div style="display: inline;float: right;">

		Totale degli articoli nel carrello: <b><?php echo $carrello->getNumeroArticoli(); ?></b></br>
		Totale del carrello: Euro <b><?php echo $carrello->getTotaleFormattatoEuro(); ?></b>
		
		<?php
			if ($carrello->getNumeroArticoli() >0) 
			 echo ' <br/><a href="mostra_carrello.php">Dettagli carrello</a>';
		?>

		
</div>

<br style="clear:both"/>
<form id="ricerca" onsubmit="return CatalogoFiltrato(this);">

			  <fieldset>

				<legend>Opzioni di rierca</legend>

				<input placeholder="Codice" type="text"> <input placeholder="Descrizione" type="text"> <input placeholder="Marca" type="text"><br>

				<br/>

				<input type="submit" value="ricerca"  />

			  </fieldset>

			</form>

<div>
<?php
if($pag!="cerca")
{
echo"<select onchange=cambia_elementi(this)>";
for($i=1;$i<=10;$i++)
{
	if(isset($_COOKIE['num']))
	{	
		if($_COOKIE['num']==$i)
			echo"<option selected>$i</option>";
		else
			echo"<option>$i</option>";
	}
	else	
		echo"<option>$i</option>";
}
echo"</select>";
}
?>
</div>
 <table border="1" width="100%">


  <thead>

	<tr>

            <th>Codice</th>

            <th>Descrizione</th>

            <th>Marca</th>

             <th>Prezzo</th>

              <th>Seleziona articolo e:</th>

       </tr>

  </thead>


<tbody>
<?php
   	foreach($catalogo->getArticoli() as $key=>&$valore)
	{
		$codice=$valore['articolo']->getCodice();
		$marca=$valore['articolo']->getMarca();
		$descrizione=$valore['articolo']->getDescrizione();
		$prezzo=$valore['articolo']->getPrezzo();
		echo"<tr><td>".$codice."<td>".$descrizione."<td>".$marca."<td>".$prezzo."<td><a href=\"mostra_dettaglio.php?codicedettaglio=".$codice."\">Visualizza dettagli prodotto</a> <a href=\"aggiungi_al_carrello.php?codice=$codice&marca=$marca&prezzo=$prezzo\" onclick=\"return confermaAcquisto('".$descrizione."');\">Aggiungi al carrello</a></tr>";
	}
if($pag != "cerca" )
{
	if($paginazione->getNumPag()!=1)
		echo"<tr style=\"text-align:center;\"><td colspan=5>";
if($paginazione->controlloPrec())
{

	$prev=$paginazione->prec();
	echo"<a href=\"$_SERVER[PHP_SELF]?pag=$prev&id=".rand()."\" style=\"text-decoration:none\">Prev</a>&nbsp;";
}	
if($paginazione->getNumpag()>1)
for($i=1;$i<=$paginazione->getNumpag();$i++)
{
	echo"<a href=\"$_SERVER[PHP_SELF]?pag=$i&id=".rand()."\">";
	if($i==$paginazione->getCurrent())
		echo "<span id=\"click\">$i</span>";
	else
		echo"$i";
	echo"</a>&nbsp;";
}
if($paginazione->controlloSucc())
{	
	$succ=$paginazione->next();
	echo"<a href=\"$_SERVER[PHP_SELF]?pag=$succ&id=".rand()."\" style=\"text-decoration:none\">Next</a>&nbsp;";

}
if($paginazione->getNumPag()!=1)
	echo"</tr>";
}
?>
</tbody>
</table>
<hr/>
<h3>Informazioni</h3>
    <ul>
        <li><b>Scheda prodotto</b>:&nbsp;Visualizza i dettagli del prodotto</li>
        <li><b>Aggiungi al carrello</b>:&nbsp;Inserisce l'articolo nel carrello elettronico d'acquisto</li>
    </ul>

<h3>Solo per debug</h3>	
<p><a href="aggiungi_al_carrello.php?svuota=1" onclick="return confirm('Azzerare il carrello?');"> Svuota il carrello</a>
<?php
if($pag=="cerca")
	echo"<a href=\"$_SERVER[PHP_SELF]\"> Mostra catalogo</a>";
?>
</p>

</body>
</html>
