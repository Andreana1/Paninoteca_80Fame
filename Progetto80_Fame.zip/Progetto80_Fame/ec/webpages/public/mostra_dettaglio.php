<?php

include_once('../../components/public/ecommerce/ECommerceFacade.php');

session_start();
?>

<html>

<head>

<title>Scheda dettagliata</title>

</head>

<body>

<h1>Scheda Dettagliata</h1>
<br>

<table border='1'>

	<tr>

		<th>Codice</th>
		<th>Descrizione</th>

		<th>Marca</th>

		<th>Prezzo</th>
		
	</tr>

			
<?php

	$catalogo=$_SESSION['catalogo'];
	if(isset($_GET['codicedettaglio']))

	{

		if(($Articolo = $catalogo->cercaArticolo($_GET['codicedettaglio']))!=null)

		{			
			
			echo "<tr><td>".$Articolo['articolo']->getCodice()."<td>".$Articolo['articolo']->getDescrizione()."<td>".$Articolo['articolo']->getMarca()."<td>".$Articolo['articolo']->getPrezzo()."</tr>";
?>	



</table>


<a href="mostra_catalogo.php"> Torna al catalogo</a>
</body>

</html>

<?php
		}
	}
?>	
