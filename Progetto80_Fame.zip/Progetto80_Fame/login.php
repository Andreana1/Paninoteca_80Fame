<?php

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>


<head>
 <title>80Fame</title>
 
<link href="login.css" type="text/css" rel="stylesheet" />


</head>
<?php
	require('db.php');
	session_start();
    // If form submitted, insert values into the database.
    if (isset($_POST['username'])){
		
		$username = stripslashes($_REQUEST['username']); // removes backslashes
		$username = mysqli_real_escape_string($con,$username); //escapes special characters in a string
		$password = stripslashes($_REQUEST['password']);
		$password = mysqli_real_escape_string($con,$password);
		
	//Checking is user existing in the database or not
        $query = "SELECT * FROM `users` WHERE username='$username' and password='".md5($password)."'";
		$result = mysqli_query($con,$query) or die(mysql_error());
		$rows = mysqli_num_rows($result);
        if($rows==1){
			$_SESSION['username'] = $username;
			header("Location: index2.php"); // Redirect user to index2.php
            }else{
				echo "<div class='form'><h3>Username/password non sono corrette.</h3><br/>Clicca per il <a href='login.php'>Login</a></div>";
				}
    }else{
?>
<div class="centro">
  <img id= "logo" src="images/LOGO.png" width=172px, height=140px><br><br>
<div class="form">
<h1>Log In</h1>
<form action="" method="post" name="login">
<input type="text" name="username" placeholder="Username" required value=""   pattern="[A-Za-z]{1,10}" title="Username massimo 10 caratteri"><br><br>
<input type="password" name="password" placeholder="Password" required  value="" ppattern="[A-Za-z0-9]{1,10}" title="Password  massimo 10 caratteri"><br><br>
<input name="submit" type="submit" value="Login" /><br>
</form>
<p>Non ancora registrato?<a href='registration.php'>Registrati QUI</a></p>
</div>
</div>
<?php } ?>


</body>
</html>